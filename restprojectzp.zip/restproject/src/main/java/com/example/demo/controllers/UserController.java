package com.example.demo.controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.User;
import com.example.demo.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping("")
	public ResponseEntity getAllUsers() {
		return new ResponseEntity(this.userService.getAll(),HttpStatus.OK);
	}
	
	
	@PostMapping("")
	public ResponseEntity createUser(@RequestBody User user) {
		this.userService.create(user);
		return new ResponseEntity("data created successfully",HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity getUserById(@PathVariable int id) {
		User user=this.userService.getById(id);
		if(user==null) {
			return new ResponseEntity("user with specify id not found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(user,HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity deleteUser(@PathVariable int id) {
		User user=this.userService.getById(id);
		if(user==null) {
			return new ResponseEntity("user with specify id not found",HttpStatus.NOT_FOUND);
		}
		this.userService.delete(id);
		return new ResponseEntity ("data deleted successfully",HttpStatus.OK);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity updateUser(@PathVariable int id,@RequestBody User user) {
		User userexist=this.userService.getById(id);
		if(userexist==null) {
			return new ResponseEntity("user with specify id not found",HttpStatus.NOT_FOUND);
		}
		this.userService.update(id, user);
		return new ResponseEntity( "user updated successfully",HttpStatus.OK);
	}
	
	
}
