package com.example.demo.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Service;

import com.example.demo.models.User;

@Service
public class UserService {
	 HashMap<Integer, User> data= new HashMap();
	 AtomicInteger atoInteger=new AtomicInteger();
	 
	 public void create(User user) {
		 user.setId(atoInteger.incrementAndGet());
		 this.data.put(user.getId(), user);
		 System.out.println(data);
	 }
	 
	 public Collection<User> getAll() {
		 return this.data.values();
	 }
	 
	 public User getById(int id) {
		 return this.data.get(id);
	 }
	 
	 public void update(int id,User user) {
		 user.setId(id);
		 this.data.put(user.getId(), user);
	 }
	 
	 public void delete(int id) {
		 this.data.remove(id);
	 }
}
