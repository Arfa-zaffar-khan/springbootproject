package com.example.demo.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.models.User;
import com.example.demo.repos.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo userRepo;

	public User create(User user) {
		return this.userRepo.save(user);
	}

	public Iterable<User> getAll() {
		return this.userRepo.findAll();
	}

	public User getById(int id) {
		return this.userRepo.findById(id).orElseThrow(() -> {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "user with specify id not found");
		});
	}

	public User update(int id, User user) {
		this.userRepo.findById(id).orElseThrow(() -> {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "user with specify id not found");
		});

		user.setId(id);
		return this.userRepo.save(user);
	}

	public User delete(int id) {
		User user = this.userRepo.findById(id).orElseThrow(() -> {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "user with specify id not found");
		});

		this.userRepo.deleteById(id);
		return user;
	}
}
